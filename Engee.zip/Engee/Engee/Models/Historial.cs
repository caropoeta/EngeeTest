﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Engee.Models
{
    public class Historial
    {
        public int ingreso { get; set; }
        public string visito { get; set; }

        public string fecha { get; set; }
        public string hora { get; set; }
    }
}
