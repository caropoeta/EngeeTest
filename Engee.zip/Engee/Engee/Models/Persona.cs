﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Engee.Models
{
    public class Persona
    {
        public string Apellido { get; set; }
        public string Nombre { get; set; }
        public string FechaNacimiento { get; set; }
        public string Dni { get; set; }
        
        
        


    }
}
